---
name: UI/UX Design System Skill
description: Design System cho Athena CDP — MoMo brand colors, spacing, component patterns
---

# Design Skill — Athena CDP Design System

## Theme & Brand Colors (Theo MoMo UI Guidelines)

### Text Colors (txt-*)
| Token | Hex | Tailwind | Dùng cho |
|-------|-----|----------|----------|
| **txt-default** | `#303233` | `text-[#303233]` | Văn bản chính, đảm bảo độ đọc rõ ràng |
| **txt-secondary** | `#484848` | `text-[#484848]` | Văn bản phụ, thông tin bổ trợ |
| **txt-hint** | `#727272` | `text-[#727272]` | Văn bản gợi ý hoặc trạng thái chờ |
| **txt-disable** | `#c6c6c6` | `text-[#c6c6c6]` | Văn bản bị vô hiệu hóa |
| **txt-white** | `#ffffff` | `text-[#ffffff]` | Văn bản trên nền tối |
| **txt-pink** | `#eb2f96` | `text-[#eb2f96]` | Màu nhấn mạnh thương hiệu MoMo |
| **txt-interactive** | `#007aff` | `text-[#007aff]` | Văn bản có thể nhấn hoặc tương tác được |
| **txt-success** | `#34c759` | `text-[#34c759]` | Trạng thái thành công |
| **txt-warning** | `#fa541c` | `text-[#fa541c]` | Trạng thái cảnh báo |
| **txt-error** | `#f5222d` | `text-[#f5222d]` | Trạng thái lỗi |

### Background Colors (bg-*)
| Token | Hex | Tailwind | Dùng cho |
|-------|-----|----------|----------|
| **bg-default** | `#f2f2f6` | `bg-[#f2f2f6]` | Nền chính, sạch sẽ và thoáng |
| **bg-white** | `#ffffff` | `bg-[#ffffff]` | Nền trắng sáng cho giao diện sáng |
| **bg-pressed** | `#dfdfe6` | `bg-[#dfdfe6]` | Nền trạng thái nhấn vào |
| **bg-disable** | `#ebebf2` | `bg-[#ebebf2]` | Nền bị vô hiệu hóa |
| **bg-pink** | `#eb2f96` | `bg-[#eb2f96]` | Nền nhấn mạnh thương hiệu |
| **bg-tonal** | `#fdeaf4` | `bg-[#fdeaf4]` | Nền phụ, tạo cảm giác nhẹ nhàng |
| **bg-selected**| `#fef4fa` | `bg-[#fef4fa]` | Nền trạng thái được chọn |
| **bg-interactive**| `#007aff`| `bg-[#007aff]` | Nền tương tác, nhấn được |

### Border Colors (bd-*)
| Token | Hex | Tailwind | Dùng cho |
|-------|-----|----------|----------|
| **bd-default** | `#e8e8e8` | `border-[#e8e8e8]` | Viền cơ bản, ngăn cách nhẹ nhàng |
| **bd-surface** | `#f9f9f9` | `border-[#f9f9f9]` | Viền bề mặt trên nền sáng |
| **bd-primary** | `#eb2f96` | `border-[#eb2f96]` | Viền chính, nhấn mạnh thương hiệu |
| **bd-secondary**| `#f7acd5` | `border-[#f7acd5]` | Viền phụ |

## Typography Scale

| Element | Classes | Dùng cho |
|---------|---------|----------|
| Page title | `text-3xl font-black text-[#303233] tracking-tight` | H1 headings |
| Section title | `text-2xl font-black text-[#303233] tracking-tight` | H2 headings |
| Card title | `text-lg font-bold text-[#303233]` | Card headers |
| Label/Tag | `text-[10px] font-black uppercase tracking-widest text-[#727272]` | Tiny labels |
| Badge | `text-[9px] font-black uppercase tracking-widest px-2 py-0.5 rounded` | Status badges |
| Body | `text-sm text-[#484848] font-medium` | Descriptions (txt-secondary) |
| Stat value | `text-2xl font-black text-[#303233]` | KPI numbers |

## Spacing & Radius

| Element | Padding | Border Radius |
|---------|---------|---------------|
| Page container | `p-8 pb-24` | — |
| Hero card | `p-8` | `rounded-3xl` |
| Standard card | `p-6` | `rounded-2xl` / `rounded-3xl` |
| Button (primary) | `px-6 py-3` | `rounded-xl` |
| Button (secondary) | `px-4 py-2` | `rounded-xl` |
| Badge/Tag | `px-2 py-1` | `rounded-lg` / `rounded-md` |
| Modal | `p-8` | `rounded-[32px]` |

## Component Patterns

### Card (Standard)
```html
<div class="bg-[#ffffff] border border-[#e8e8e8] rounded-3xl p-6 shadow-sm 
            hover:border-[#eb2f96]/30 transition-all">
  <!-- content -->
</div>
```

### CTA Button (Primary)
```html
<button class="px-6 py-3 rounded-xl bg-[#eb2f96] text-[#ffffff] font-bold text-sm 
               shadow-lg shadow-pink-100 hover:opacity-90 transition-all 
               transform hover:-translate-y-0.5 active:translate-y-0">
  Action
</button>
```

### AI/LLM Highlight Section
```html
<div class="bg-gradient-to-br from-[#fdeaf4] to-[#fef4fa] border border-[#f7acd5] 
            rounded-[32px] p-8 relative overflow-hidden">
  <!-- Blur decoration -->
  <div class="absolute top-0 right-0 w-64 h-64 bg-[#eb2f96]/10 
              rounded-full blur-3xl -mr-32 -mt-32 pointer-events-none"></div>
  <!-- Content -->
</div>
```

### AI Badge
```html
<div class="absolute -top-2 -right-2 bg-[#eb2f96] text-[#ffffff] text-[9px] 
            font-black px-2 py-0.5 rounded-full flex items-center gap-1 shadow-lg">
  <Cpu size={8} /> AI Generated
</div>
```

### Trend Indicator
```html
<!-- Positive -->
<div class="flex items-center gap-1 text-[10px] font-black px-2 py-1 
            rounded-lg bg-[#34c759]/10 text-[#34c759]">
  <TrendingUp size={12} /> +5.2%
</div>
<!-- Negative -->
<div class="... bg-[#f5222d]/10 text-[#f5222d]">
  <TrendingDown size={12} /> -3.1%
</div>
```

### Table Header (Default)
```html
<thead>
  <tr class="bg-[#f2f2f6] border-b border-[#e8e8e8] text-[#727272]">
    <th class="px-6 py-4 text-[10px] font-black uppercase tracking-[0.2em] opacity-80">
      Column Name
    </th>
  </tr>
</thead>
```

### Tooltip
```html
<div class="group relative inline-block">
  <Info size={14} class="text-[#727272] hover:text-[#303233] cursor-help" />
  <div class="invisible group-hover:visible absolute z-50 bottom-full 
              left-1/2 -translate-x-1/2 mb-2 w-48 p-2 bg-[#303233] 
              text-[#ffffff] text-[10px] rounded shadow-xl text-center">
    Tooltip text
  </div>
</div>
```

## Design Principles

1. **Premium feel**: Dùng `font-black`, `tracking-widest`, `shadow-lg` tạo cảm giác high-end
2. **Subtle animations**: `hover:-translate-y-0.5`, `transition-all`, Framer Motion
3. **Consistent spacing**: Cards luôn `gap-6` hoặc `gap-8`, sections `mb-8` hoặc `mb-16`
4. **AI-first branding**: Sections AI dùng `bg-tonal` (`#fdeaf4`), badges `#eb2f96`
5. **Data density**: Tables compact (`text-[11px]`), cards show max info without scroll
6. **Function Color Mapping**: Bắt buộc map đúng chức năng (e.g. `bg-default` cho nền app, `bg-white` cho card)
7. **Responsive**: `grid-cols-1 md:grid-cols-2 lg:grid-cols-3` cho card grids

## Do's and Don'ts

| ✅ Do | ❌ Don't |
|-------|----------|
| Dùng `bg-pink` (`#eb2f96`) cho brand accent | Dùng `#B0006D` cũ hoặc generic blue/red/green |
| Sử dụng đúng Function Variable (Background, Text, Border) | Dùng lẫn lộn màu text cho background hoặc ngược lại |
| `font-black` + `tracking-widest` cho labels | `font-normal` cho labels |
| `rounded-2xl` trở lên cho cards | `rounded` (quá nhỏ) |
| `bg-tonal` (`#fdeaf4`) cho AI sections | Plain white cho AI sections |
| `shadow-sm` cho cards, `shadow-lg` cho CTAs | Quá nhiều shadow |
| Lucide React icons | FontAwesome hay Heroicons |
